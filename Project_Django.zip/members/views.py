from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm

def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            messages.success(request,username)
            return redirect('login')
    else:
        return render(request, 'members/login.html', {} )

def logout_user(request):
    logout(request)
    messages.success(request,{"You were Logged Out"})
    return redirect("login")

def register_user(request):
    username = request.POST.get('username')
    email = request.POST.get('email')
    password = request.POST.get('psw')
    return render(request, 'members/registeration.html', {} )
